from django.urls import path 
from . import views
from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('register/',views.register_view,name='register'),
    path('',views.login_view,name='login'),
    path('edit /<int:id>',views.edit,name='edit'),
    path('delete /<int:id>',views.delete,name='delete'),
    path('logout/',views.logout_view,name='logout'),
    path('dashboard/',views.dashboard_view,name='dashboard'),
    path('details/',views.details_view,name='details'),
    path('details/', views.index,name='index'),
    path('<int:id>',views.view_student, name="view_student"),
    path('add/',views.add,name='add'),
    # path('', include('student.urls')),
    # path('admin/', admin.site.urls),
    # path('auth_app/', include(('auth_app.urls','auth_app'),namespace='auth_app')),
]