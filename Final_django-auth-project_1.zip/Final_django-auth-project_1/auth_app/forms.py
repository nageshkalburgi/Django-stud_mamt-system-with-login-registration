from django import forms
from . models import Student


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'email', 'phone', 'department_no']
        labels = {
          # 'student_number': 'Student Number', 
          'first_name': 'First Name', 
          'email': 'Email', 
          'phone' : 'phone',
          'department_no':'department_no'
      }

    widgets = {
      # 'student_number': forms.NumberInput(attrs={'class': 'form-control'}), 
      'first_name': forms.TextInput(attrs={'class': 'form-control'}),
      'email': forms.EmailInput(attrs={'class': 'form-control'}),
      'phone': forms.TextInput(attrs={'class': 'form-control'}),
      'department_no': forms.NumberInput(attrs={'class': 'form-control'}),
      
}