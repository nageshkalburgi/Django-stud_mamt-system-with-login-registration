from django.contrib import admin
from . models import Student
class stu(admin.ModelAdmin):
    list_display = ['first_name','email','phone','department_no']
# Register your models here.
admin.site.register(Student)