from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import login, logout
from .middlewares import auth, guest
from django.http import HttpResponseRedirect
from .models import Student

from django.urls import reverse
# from ..auth_app.models import Student
from .forms import StudentForm
from .models import Student

# Create your views here.

@guest
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request,user)
            return redirect('dashboard')
    else:
        initial_data = {'username':'', 'password1':'','password2':""}
        form = UserCreationForm(initial=initial_data)
    return render(request, 'auth/register.html',{'form':form})

@guest
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request,user)
            return redirect('dashboard')
    else:
        initial_data = {'username':'', 'password':''}
        form = AuthenticationForm(initial=initial_data)
    return render(request, 'auth/login.html',{'form':form}) 

@auth
def dashboard_view(request):

    return render(request, 'dashboard.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@auth
def details_view(request):
    obj = Student.objects.all()
    context = {
        'students':obj
    }
    return render(request, 'auth/details.html',context)
    # return render(request, 'details.html')







# Create your views here.
def index(request):
    return render(request, 'auth/details.html',{
        'auth_app': Student.objects.all()
    })

def view_student(request, id):
    student = Student.objects.get(pk=id)
    return HttpResponseRedirect(reverse('details'))

def add(request):
  if request.method == 'POST':
    form = StudentForm(request.POST)
    print(form)
    if form.is_valid():
    #   new_student_number = form.cleaned_data['student_number']
      new_first_name = form.cleaned_data['first_name']
      new_email = form.cleaned_data['email']
      new_phone =form.cleaned_data['phone']
      new_department_number = form.cleaned_data['department_no']
      print(new_first_name)
      new_student = Student(
        # student_number = new_student_number,
        first_name = new_first_name,
        email = new_email,
        phone=new_phone,
        department_no = new_department_number
      )
      new_student.save()
      return render(request, 'auth/add.html', {
        'form': StudentForm(),
        'success': True
      })
  else:
    form = StudentForm()
  return render(request, 'auth/add.html', {
    'form': StudentForm()
  })

def edit(request, id):
    if request.method == 'POST':
        student = Student.objects.get(pk=id)
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
        return render(request, 'auth/edit.html', {
            'form': form,
            'success': True
        })
    else:
        student = Student.objects.get(pk=id)
        form = StudentForm(instance=student)
    return render(request, 'auth/edit.html', {
        'form': form
})

def delete(request, id):
  if request.method == 'POST':
    student = Student.objects.get(pk=id)
    student.delete()
  return HttpResponseRedirect(reverse('index'))
