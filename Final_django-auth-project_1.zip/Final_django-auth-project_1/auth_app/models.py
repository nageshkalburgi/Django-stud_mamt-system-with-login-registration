from django.db import models

class Student(models.Model):
  
    DEPARTMENT_CHOICES = [
        ('dept_1', 'Department 1'),
        ('dept_2', 'Department 2'),
        ('dept_3', 'Department 3'),
        ('dept_4', 'Department 4'),
    ]
    first_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    department_no = models.CharField(max_length=10, choices=DEPARTMENT_CHOICES)
   

    def __str__(self):
        return self.first_name
